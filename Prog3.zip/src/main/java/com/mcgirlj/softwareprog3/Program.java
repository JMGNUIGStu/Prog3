package com.mcgirlj.softwareprog3;
public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/* As mentioned in my report Eclipse was unable to find JodaTime, I have been unable to debug this as the 
		 * intellisense recommends objects and constructors correctly but the class is not found on compilation
		 * I have added screenshots showing it is correctly added to my buildpath and refereced correctly in pom.xml and
		 * the project itself so I have opted for java.Time
		 */
	}

}
